<p align="center">
  <a href="https://miris.com">
    <img src="https://cdn.jsdelivr.net/npm/@miris-inc/core/banner.svg" alt="Miris" width="100%" />
  </a>
</p>

# @miris-inc/core

Core scene-graph runtime for the Miris 3D streaming SDK. Provides the WASM-backed Engine, Scene, Stream, LOD, Camera, and ModelRoot primitives shared by all higher-level packages.

## Install

```bash
npm install @miris-inc/core
```

## Usage

### From a CDN

```html
<script type="module">
  import { Miris } from "https://unpkg.com/@miris-inc/core";
</script>
```

CDNs serve the **standalone build** — a single self-contained JS file with all WASM inlined. No additional files to host.

### With a bundler (Vite, Webpack, esbuild)

```js
import { Miris, Scene, Stream } from "@miris-inc/core";

const miris = await Miris.instance();
```

The default import resolves to the **chunked build** — a lightweight JS module with WASM loaded as a separate file. Your bundler handles WASM loading automatically via the standard `new URL("AquaApi.wasm", import.meta.url)` pattern.

### Standalone import via bundler

If you want the self-contained build in a bundler context:

```js
import { Miris } from "@miris-inc/core/standalone";
```

## Builds

| Build | File | Description |
|-------|------|-------------|
| Chunked | `core.js` + `AquaApi.wasm` | Unminified. Default for bundlers in dev mode. WASM loaded separately. |
| Chunked prod | `core.prod.js` + `AquaApi.wasm` | Minified. Default for bundler production builds. |
| Standalone | `core.standalone.js` | Unminified, readable source with WASM inlined. `import.meta.env.DEV` is `true`. |
| Standalone prod | `core.standalone.prod.js` | Minified production bundle. Served by `unpkg`/`jsdelivr`. |

## Exports

Both `"."` and `"./standalone"` use the `development` export condition — bundlers in dev mode automatically resolve to the unminified build.

```js
// Bundler (chunked, default)
import { Miris } from "@miris-inc/core";

// CDN / standalone
import { Miris } from "@miris-inc/core/standalone";
```

## API

| Export | Description |
|--------|-------------|
| `Miris` | Main application singleton. Manages engine lifecycle, scenes, and the update loop. |
| `Scene` | A streaming scene connected to a Miris asset. |
| `Stream` | A single stream within a scene. |
| `Lod` | A level-of-detail node containing splat data. |
| `Camera` | Camera state pushed to the streaming engine. |
| `ModelRoot` | Root transform for a streamed model. |
| `Change` | Describes a scene-graph mutation (created, modified, activated, deactivated, deleted). |

## License

Apache-2.0
